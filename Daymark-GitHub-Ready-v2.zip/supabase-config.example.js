// Insert the URL and PUBLISHABLE (or legacy anon) key from your Supabase project.
// This key is designed to be visible in browser code. NEVER paste a secret/service_role key here.
window.DAYMARK_CONFIG = {
  url: "YOUR_SUPABASE_PROJECT_URL",
  publishableKey: "YOUR_SUPABASE_PUBLISHABLE_KEY"
};

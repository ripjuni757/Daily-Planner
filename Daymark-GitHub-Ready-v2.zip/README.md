# DAYMARK — Private Planner with Accounts

**Updated GitHub Pages release — November 2026**

A navy-and-white weekly planner and monthly calendar with email/password signup and login. Each person's tasks are saved to their own Supabase account, with database Row Level Security (RLS).

## YOU ALREADY ADDED YOUR SUPABASE URL AND KEY TO GITHUB?

**Great! Keep your existing `supabase-config.js` unchanged.** This ZIP deliberately does **not** include that file, so uploading its contents **will not overwrite your working configuration**.

1. Download this ZIP, right-click it, and choose **Extract All**.
2. Open the extracted `Daymark-GitHub-Ready` folder. **Select the individual files inside** (not the outer folder, and not the ZIP).
3. On GitHub, open your Daymark repository and choose **Add file → Upload files**. Drag the files from the extracted folder into the upload area. Accept replacing the older `index.html`, `style.css`, etc.
4. Click **Commit changes**. The repository's **root** should contain `index.html`, `login.html`, `style.css`, `app.js`, `auth.js`, `supabase-client.js`, AND your **existing** `supabase-config.js`.
5. On GitHub, go to **Settings → Pages → Deploy from a branch → main → / (root) → Save** (if not already enabled).
6. Visit `https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/login.html`. Test creating an account and signing in.

Do not remove or overwrite your existing `supabase-config.js`. It needs this exact format:

```javascript
window.DAYMARK_CONFIG = {
  url: "https://YOUR-PROJECT-ID.supabase.co",
  publishableKey: "sb_publishable_YOUR_KEY"
};
```

Use your own real URL and **publishable** key (or legacy anon key), **never** a `service_role`, `sb_secret_...` key, or database password. The publishable key is meant to appear in frontend code. Supabase RLS, not hiding the key, protects private tasks.

### If you have NOT yet created `supabase-config.js`

On GitHub, use **Add file → Create new file** and name it `supabase-config.js`. Copy the contents of `supabase-config.example.js` and replace the placeholders with your own project URL and publishable key, then commit.

## One-time Supabase setup

1. Supabase dashboard → **Authentication → Sign In / Providers → Email**: enabled.
2. Supabase dashboard → **SQL Editor**: run `supabase.sql` to create the `daymark_tasks` table with RLS.
   - If you **already created** the `daymark_tasks` table in Table Editor by running our earlier SQL, **skip this step**; no need to run it again.
3. Supabase dashboard → **Authentication → URL Configuration**:
   - **Site URL**: `https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/`
   - **Redirect URLs**, add:
     - `https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/login.html`
     - `https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/`
   - If using a custom domain, use the matching custom domain instead.
4. Verify signup → email confirmation (if required) → login → add task → log out → log back in. Check that your task remains. Register another test account and verify it cannot see the first account's tasks.

**About the SQL file:** The included SQL is safe to run repeatedly because the RLS policy definitions use `DROP POLICY IF EXISTS`; it does not drop the table or user tasks. For an existing working setup there is no reason to rerun it.

## Files in this download

| File | Purpose | Upload to GitHub? |
|---|---|---|
| `index.html` | Weekly planner and full monthly calendar | Yes |
| `login.html` | Login, signup, forgot-password UI | Yes |
| `style.css` | Navy/white styling with professional square corners | Yes |
| `app.js` | Tasks, reminders, calendar, imports/exports, personal cloud storage | Yes |
| `auth.js` | Account signup/login/recovery | Yes |
| `supabase-client.js` | Supabase browser connection | Yes |
| `supabase-config.example.js` | Safe sample only; actual key stays in `supabase-config.js` | Optional |
| `supabase.sql` | Database + security policies; run in Supabase SQL Editor | Optional |
| `README.md` | Setup guide | Yes |

You must have `supabase-config.js` **in the GitHub repository root** beside `index.html`; it is not in the ZIP because you already made this file.

## Planner features

- Week-by-week hour grid and complete monthly calendar
- Add, edit, delete, categorize, prioritize and complete tasks and reminders
- All-day items; searchable notes; mini-calendar and weekly progress
- Notification alerts **only while the website is open**, if permitted by the browser
- JSON backups, import `.ics`, `.csv`, or `.json`; export `.ics`
- Private Supabase tasks per user, available on multiple devices after signing in
- Browser-specific display preferences; no live collaboration or automatic cross-device updating without page reload

## Troubleshooting

- **Planner says "needs configuration"**: Ensure `supabase-config.js` is in the repository root, with `window.DAYMARK_CONFIG` and a valid project URL and publishable key.
- **"Could not load your planner" / `daymark_tasks` missing**: Ensure the SQL was run in the **same Supabase project** whose URL you entered.
- **Confirmation email opens wrong website**: Check **Authentication → URL Configuration** and `login.html` redirect URL.
- **Signup email never arrives**: Check spam and Supabase email limits. Supabase's default email service is restricted and not suitable for launching widely; set up custom SMTP and anti-bot/rate-limit protections before opening registration publicly.
- **Changes not visible**: Give GitHub Pages time to deploy and refresh. The root folder and file names are case-sensitive (`style.css`, not `Style.css`).
- **Existing tasks from the old browser-only Daymark**: Use **Settings → Import tasks from the original browser-only Daymark** on the same browser, or import a JSON backup.

Do not store secrets in GitHub Pages. `supabase-config.js` contains only the intentionally public publishable/anon key. User accounts are handled by Supabase Authentication; the website never stores passwords itself.

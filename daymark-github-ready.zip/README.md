# DAYMARK — Personal Planner

A polished, responsive daily and weekly planner built with **HTML and CSS files**, with no frameworks, libraries, accounts or build tools required.

## Publish it on GitHub Pages

1. Create a public GitHub repository (e.g. `daymark-planner`).
2. Upload `index.html` and `style.css` to the **root** of the repository. Commit the change.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Visit the GitHub Pages URL shown in the Pages settings.

You can also double-click `index.html` to try the planner locally before uploading it.

## Features

- Interactive seven-day, 24-hour week view. Click a time slot to schedule a task.
- Full monthly calendar, plus a compact calendar in the sidebar.
- Create, edit, complete, and delete tasks and important reminders.
- All-day items, categories, priorities, detailed notes and reminder lead times.
- Automatic handling of overlapping events in weekly view.
- Search by title, notes or date; weekly/monthly progress summaries.
- Optional browser notifications while the site is open and browser permission is granted.
- Import `.ics` calendar events, `.csv` tasks, and `.json` backups.
- Export `.ics` calendars and full `.json` backups.
- Settings for week start, clock format, and default task length.
- Keyboard shortcuts: `N` for new task, `/` to search.
- Responsive desktop/mobile styling.

### CSV format

A CSV import must have at least `title,date` columns. Date must be in `YYYY-MM-DD` format. Optional columns: `start,end,kind,category,priority,notes,allDay,reminder,completed`.

Example:

```csv
title,date,start,end,kind,category,priority,notes,allDay,reminder
Finish history project,2026-11-12,16:00,17:30,task,study,high,Review sources,false,15
College deadline,2026-11-18,,,reminder,personal,high,Submit form,true,none
```

### Important data note

**The planner uses localStorage.** Tasks are saved in the current browser on the current device; GitHub Pages hosts the application code, **not your personal tasks**. Different devices/browsers will not sync automatically. Use **Tools → Download backup** and **Tools → Restore backup** to move your plans. Clearing your browser storage can remove them. Browser notifications work only while the page is open; they are not a background push service.

### Notes on `.ics`

The `.ics` importer supports basic dated events (including all-day and UTC timestamps). Advanced recurring-event rules (`RRULE`) and complex time-zone definitions aren't expanded in this first version.

## Customizing the appearance

Edit the CSS variables near the top of `style.css`. The default palette is navy, blue-white and muted slate, with Georgia/Cambria/Times-style typography and squared edges.

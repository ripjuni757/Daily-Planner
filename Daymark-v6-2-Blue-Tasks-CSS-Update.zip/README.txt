Daymark v6.2 - Blue Tasks Color Update

Regular tasks: blue (#2866a6). Reminders: red (#b43b48). Recurring activities: purple (#7848b6).

GitHub: Replace ONLY style.css in the root of your Daily-Planner repository. Keep app.js, index.html, supabase-config.js, and all other files unchanged.
After committing, wait for GitHub Pages deployment then hard refresh (Ctrl+Shift+R).
You may use Daymark-style-code.txt to copy/paste the same CSS into GitHub if your browser blocks .css downloads.
